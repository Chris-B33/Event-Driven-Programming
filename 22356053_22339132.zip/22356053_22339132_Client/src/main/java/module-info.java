module com.mycompany.clientapp {
    requires javafx.controls;
    requires javafx.base;
    requires javafx.graphics;
    exports com.mycompany.clientapp;
}
